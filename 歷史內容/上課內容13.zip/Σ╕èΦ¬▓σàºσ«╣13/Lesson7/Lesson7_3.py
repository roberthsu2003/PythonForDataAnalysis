import tools
tools.get_hello("robert")

person = tools.getPerson("jenny")
print("type",type(person))
print("name", person.name)